var num1=2;
var num2=Number(true);
//构造函数
var num3=new Number(null);
//console.log(num3,typeof num3);
//console.log(num3+2);
//
console.log(Number.MAX_VALUE);//最大值
console.log(Number.MIN_VALUE);//最小值

//var num4=2*3.14*5
var num4=0.1+0.2;
var num5=2999;
//console.log(num5.toFixed(2));//取小数点后n位
var num6=13; //0xd
console.log( num6.toString(2) );








