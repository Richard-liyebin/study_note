var a=1;
//再原来基础上加1
//a++;
//在原来基础之上加1，把结果赋给a
//a=a+1;
a+=3;
//console.log(a);
//打八折，在原来基础之上打八折 *=
//声明变量保存商品单价，计算八折后的值
var price=100;
//在原来基础上乘以0.8
//price=price*0.8;
price*=0.8;
//console.log(price);

var str='a';
//str=str+'b';
str+='b';
str+='c';
str+='d';
console.log(str);


var age=true;

console.log(age===1);



