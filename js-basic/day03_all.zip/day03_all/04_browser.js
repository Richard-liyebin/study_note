//弹出警示(消息)框
//alert('hello');
//alert('world');
//弹出提示(输入)框
// '' 
//var str=prompt('please input password');
//console.log(str,typeof str);


var num1=prompt('input a number');
var num2=prompt('input a number');
//把两次输入的值转为数值型
num1=Number(num1);
num2=Number(num2);
console.log(num1+num2);


