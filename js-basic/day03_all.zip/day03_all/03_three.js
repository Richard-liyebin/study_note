//三目运算符
//根据年龄判断是否为成年人
var age=19;
//age>=18 ? console.log('成年人') : console.log('未成年人');

//练习：声明两个变量保存用户名和密码，如果用户名为root，并且密码为123456，打印登陆成功，否则打印登陆失败
var uname='root',upwd='123456';
uname==='root' && upwd==='123456' ? console.log('登陆成功') : console.log('登陆失败');









