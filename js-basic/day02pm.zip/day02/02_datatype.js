//整型
//十进制
var num1=13;
//八进制
var num2=012;
//十六进制
var num3=0Xc;
//打印的结果不管写的是多少进制，最终都是十进制
//console.log(num3);
//浮点型
var f1=3.14e3;
var f2=3.14e-1;
var f3=3.14;
//console.log(f1,f2);

//检测数据类型
//console.log(typeof f3);


//字符串型
var str1='hello';
var str2='3';
//console.log(str2,typeof str2);
//查看某个字符的Unicode码
//console.log( '然'.charCodeAt() );


//布尔型
var b1=true;
var isLogin=false;
var b2=3>4;
//console.log(b2,typeof b2);

//未定义型 
var a;//undefined
//console.log(a,typeof a);

//空
var b=null;
console.log(b,typeof b);



