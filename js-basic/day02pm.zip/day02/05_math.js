//取余
//隔行换色，判断是否为闰年
//console.log(3%2);
//console.log(2%3);

//自增和自减
var a=1;
//a++;//在原来基础上加1
//console.log(a);//2
//直接打印a++
//1.先打印a的值，此时a还是1，打印就是1，打印完后，再执行自增，这时候a变成2
//console.log(a++);
//重新从内存中获取a的值
//console.log(a);
//2.先让a的值执行自增，此时a的值变成了2，然后打印a的值
//console.log(++a);

//var b=3;
//b--;//在原来的基础上减1
//console.log(b);

var num=3;
console.log( num-- + --num );

