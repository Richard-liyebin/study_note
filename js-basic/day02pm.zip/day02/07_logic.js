//判断一个人的工资是否在5000~8000之间
var salary=2000;
//console.log( salary>=5000 && salary<=8000 );
//练习：声明两个变量分别保存用户名和密码，如果用户名为'root'，并且密码为'123456'，打印true，否则false
var uname='root';
var upwd='123456';
//console.log(uname==='root' && upwd==='123456');

//判断是满足让座标准
//儿童12岁以下或者老人65岁以上
var age=5;
//console.log(age<=12 || age>=65);

//练习：声明变量保存用户，如果使用用户名root，或者使用手机号码18112345678，满足其一打印true，否则打印false
var user='root';
//console.log( user==='root' || user==='18112345678' );

//取反向
var r=1>3;
//console.log( !r );


var num=3;
//num>5  &&  console.log(a);
//num<1  ||  console.log(a);


var age=15;
age>=18 && console.log('成年人');














