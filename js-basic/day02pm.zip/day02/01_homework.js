//声明变量保存半径
var r=5;
//声明常量保存圆周率
const pi=3.14;
//声明变量保存周长和面积
var area,length;
area=pi*r*r;
length=2*pi*r;
//小数运算时，可能产生误差
//console.log(area,length);

var price1=20,num1=13;
var price2=5.5,num2=17.3;
var total=price1*num1+price2*num2;
console.log(total);
console.log(0.1+0.2);





