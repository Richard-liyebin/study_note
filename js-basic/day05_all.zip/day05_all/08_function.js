fn();
function fn(){
  console.log(1);
}
