//使用内置构造函数创建对象
var car=new Object();
//添加属性
car.brand='五菱宏光';
car.color='白色';
car['price']=60000;
//console.log(car);
//练习: 创建一个笔记本对象，包含编号，标题，价格，规格
var laptop=new Object();
laptop.lid=21;
laptop.title='小米Air';
laptop['price']=3999;
laptop['spec']='游戏本';
console.log(laptop);







