//包装成字符串对象
var str1=new String(3);
//console.log(str1,typeof str1);
//console.log(str1+'b');
//将任意的数据转为字符串
var str2=String(true);
//console.log(str2,typeof str2);
var str3='a';

//转义字符  \
console.log('It\'s a dog');
console.log('hello \no world');
console.log('a\tb');
console.log('welcome to chi\\na');







