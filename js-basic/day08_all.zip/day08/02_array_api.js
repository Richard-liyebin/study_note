//var arr=[23,9,78,6,45];
//数组元素排序
//默认按照Unicode码从小到大
//console.log( arr.sort() );
//按照数字大小排序
//console.log( arr.sort(function(a,b){
//  return b-a;
//}) );
/*
作用
参数
返回值
*/
var arr=['html','css','js'];
//arr[arr.length]='nodejs';
//在数组末尾添加元素
//console.log( arr.push('nodejs') );
//删除数组末尾的元素
//console.log( arr.pop() );
//在开头添加元素
//console.log( arr.unshift('vuejs') );
//删除开头的元素
//console.log( arr.shift() );
//console.log(arr);

//练习：创建数组，包含有多个员工数据(对象)，包含属性有编号、姓名、工资
var emps=[
  {eid:1,ename:'tom',salary:8000},
  {eid:2,ename:'king',salary:10000}
];
var person={
  name:'小然',
  age:88,
  love:['抽烟','烫头','喝酒']
}












