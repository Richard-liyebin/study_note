/*
//获取圆周率
console.log( Math.PI );
//取绝对值 
console.log( Math.abs(18-21) );
//parseInt
//向上取整
console.log( Math.ceil(5.01) );
//向下取整
console.log( Math.floor(4.999) );
//四舍五入取整
console.log( Math.round(4.49) );
*/
//取一组数字的最大值
console.log( Math.max(23,9,78,45,6) );
//取一组数字的最小值
console.log( Math.min(23,9,78,45,6) );
//x的y次幂
console.log( Math.pow(5,2) );
//取随机  >=0  <1
console.log( Math.random() );

