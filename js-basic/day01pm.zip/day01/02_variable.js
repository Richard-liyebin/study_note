//声明变量
var x=1;
//console.log(x);
var eid=15;
var ename='tom';
var sex=1;
var birthday='1998-10-20';
var salary=8000;
var deptId=20;
//var 国家='中国';
//console.log(eid,ename,sex,birthday,salary,deptId);

//命名规则
var _$a1=10;
//关键字不能作为变量名
//var var=3;
//console.log(_$a1);

var a=3; //TypeScript强类型语言
a=4;
a='tedu';
//console.log(a);
//声明变量未赋值 undefined
var b;
b=3+4;
//console.log(b);
//一次性声明多个变量
var c=5,d=7,e;
//var c=5;
//var d=7;
//var e;
//console.log(c,d,e);

//练习：声明变量保存语文，数学，总成绩，总成绩暂时为空，把语文和数学的和赋值给总成绩，最后打印总成绩。
var chinese=95,math=98,total;
total=chinese+math;
console.log(total);
//语义 
//userName  country_name

