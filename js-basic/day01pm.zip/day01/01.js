//console.log('hello world');
/*
 注释的内容
*/
console.log('hello world');