const sex='男';
//sex='女';
//练习：声明常量保存圆周率，一个人生日
const pi=3.14;
const birthday='5-5';
console.log(sex);

