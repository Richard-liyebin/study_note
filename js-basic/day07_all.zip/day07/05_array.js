//创建数组，包含有多个员工姓名
//数组字面量
var emps=['tom','jerry','king'];
//console.log(emps);
//练习：创建数组，包含有多个商品的名称; 创建数组，包含多个城市的名称。
var product=['西瓜','葡萄','榴莲','车厘子'];
//修改其中一个元素，添加两个元素
product[2]='香蕉';
product[4]='百香果';
product[5]='牛油果';
console.log(product);

var city=['青岛','厦门','深圳','三亚'];
//console.log(city);
//访问某个元素
//console.log( city[0] );
//console.log( city[4] );
//修改元素
city[2]='广州';
//添加元素
city[4]='杭州';
//console.log(city);










