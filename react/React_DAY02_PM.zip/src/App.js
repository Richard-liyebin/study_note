import React from 'react';
import './App.css';
import MyC01BuyCount from './MyC01BuyCount';
import MyC02 from './MyC02';
import MyC03 from './MyC03';
import MyC04 from './MyC04';
import MyC05 from './MyC05';

function App() {
  return (
    <div>
      {/* 
      <MyC01BuyCount/> 
      <MyC01BuyCount/>
      <MyC01BuyCount/>
      <MyC02 />
      <MyC03 />
      <MyC04 />
      */}
      <MyC05 />
    </div>
  );
}

export default App;
