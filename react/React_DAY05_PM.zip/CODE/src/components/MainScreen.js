import React from 'react'
import {FlatList, View, Text, Button, Image, TouchableOpacity, ActivityIndicator} from 'react-native'

export default class MainScreen extends React.Component{
  render(){
    return (
      <View>
        <Text>这里是主菜单屏幕</Text>
      </View>
    )
  }
}