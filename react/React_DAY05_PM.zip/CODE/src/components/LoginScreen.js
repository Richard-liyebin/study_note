import React from 'react'
import {FlatList, View, Text, Button, Image, TouchableOpacity, ActivityIndicator} from 'react-native'

export default class LoginScreen extends React.Component{
  render(){
    return (
      <View>
        <Text>这里是登录屏幕</Text>
      </View>
    )
  }
}