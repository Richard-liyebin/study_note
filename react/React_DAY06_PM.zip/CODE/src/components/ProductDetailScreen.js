import React from 'react'
import {View, Text, Image} from 'react-native'

export default class ProductDetailScreen extends React.Component{
  //配置页头
  static navigationOptions = ((obj)=>{
    return {
      title: '商品'+obj.navigation.getParam('pid',999)+'的详情'
    }
  })

  constructor(){
    super()
    this.state = { }
  }
  componentDidMount(){
    //组件挂载完成，读取前一个路由组件传递过来的参数
    //console.log(this.props.navigation.state.params)
    let pid = this.props.navigation.getParam('pid',999)
    console.log(pid)
  }
  render(){
    return (
      <View>
        <Text>商品详情</Text>
      </View>
    )
  }
}