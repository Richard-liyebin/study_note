print('hello')
print(123)
print('world')